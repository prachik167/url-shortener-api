const express = require('express');
const router = express.Router();
const Url = require('../models/Url');
const { nanoid } = require('nanoid'); // Import nanoid for generating unique codes

// Shorten URL Endpoint
router.post('/shorten', async (req, res) => {
  const { originalUrl, customCode } = req.body;

  // Validate originalUrl
  if (!originalUrl) {
    return res.status(400).json({ error: 'Original URL is required' });
  }

  // Check if a custom short code was provided, otherwise generate one
  const shortCode = customCode || nanoid(7);

  try {
    // Check if the short code already exists
    const existingUrl = await Url.findOne({ shortCode });
    if (existingUrl) {
      console.error('Short code already exists:', shortCode);
      return res.status(400).json({ error: 'Short code already exists' });
    }

    // Create a new URL document
    const newUrl = new Url({ originalUrl, shortCode });
    await newUrl.save();

    // Send the response with the shortened URL
    res.json({
      originalUrl,
      shortUrl: `${req.protocol}://${req.get('host')}/${shortCode}`
    });
  } catch (err) {
    console.error('Error saving URL:', err);
    res.status(500).json({ error: 'Server error. Please try again later.' });
  }
});

module.exports = router;
