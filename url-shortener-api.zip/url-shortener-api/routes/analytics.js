// routes/analytics.js
const express = require('express');
const router = express.Router();
const Url = require('../models/Url');
const Visit = require('../models/Visit');

router.get('/:shortCode', async (req, res) => {
  const { shortCode } = req.params;

  try {
    // Fetch original URL
    const urlMapping = await Url.findOne({ shortCode });
    if (!urlMapping) {
      return res.status(404).json({ error: 'Short URL not found' });
    }

    // Fetch visits related to the short code
    const visits = await Visit.find({ shortCode });

    // Total number of visits
    const totalVisits = visits.length;

    // Number of unique visitors (assuming unique based on IP)
    const uniqueVisitors = new Set(visits.map(visit => visit.ipAddress)).size;

    // Breakdown of visits by device type
    const deviceTypeBreakdown = visits.reduce((acc, visit) => {
      acc[visit.deviceType] = (acc[visit.deviceType] || 0) + 1;
      return acc;
    }, {});

    // Top referring websites
    const referrerBreakdown = visits.reduce((acc, visit) => {
      const referrer = visit.referer || 'Direct';
      acc[referrer] = (acc[referrer] || 0) + 1;
      return acc;
    }, {});

    // Time series data of visits
    const timeSeriesData = visits.reduce((acc, visit) => {
      const hour = visit.timestamp.getHours();
      acc[hour] = (acc[hour] || 0) + 1;
      return acc;
    }, {});

    return res.json({
      originalUrl: urlMapping.originalUrl,
      totalVisits,
      uniqueVisitors,
      deviceTypeBreakdown,
      referrerBreakdown,
      timeSeriesData,
    });
  } catch (err) {
    console.error('Error retrieving analytics:', err);
    return res.status(500).json({ error: 'Server error', details: err.message });
  }
});

module.exports = router;
