// redirect.js
const express = require('express');
const router = express.Router();
const Url = require('../models/Url');
const Visit = require('../models/Visit'); // Assuming you have a Visit model
const { cache } = require('../index'); // Import the cache instance from index.js

// Redirect Endpoint
router.get('/:shortCode', async (req, res) => {
    const { shortCode } = req.params;
    console.log('Received shortCode:', shortCode);

    try {
        // Check Redis cache for the shortCode
        const cachedUrl = await cache.get(shortCode);
        if (cachedUrl) {
            console.log('Cache hit for shortCode:', shortCode);
            await logVisit(shortCode, req); // Log the visit
            return res.redirect(cachedUrl);
        }

        // If not found in Redis, check MongoDB
        console.log('Cache miss. Searching in DB for shortCode:', shortCode);
        const urlMapping = await Url.findOne({ shortCode });
        if (!urlMapping) {
            console.log('Short URL not found in DB for shortCode:', shortCode);
            return res.status(404).json({ error: 'Short URL not found' });
        }

        // Cache the URL for future use
        console.log('Caching URL for future use:', urlMapping.originalUrl);
        await cache.set(shortCode, urlMapping.originalUrl, { EX: 60 * 60 });
        await logVisit(shortCode, req); // Log the visit
        return res.redirect(urlMapping.originalUrl);
    } catch (err) {
        console.error('Error finding shortCode:', err);
        return res.status(500).json({ error: 'Server error', details: err.message });
    }
});

// Helper function for logging visits
async function logVisit(shortCode, req) {
    const visit = new Visit({
        shortCode,
        userAgent: req.headers['user-agent'],
        ipAddress: req.ip,
        deviceType: req.headers['user-agent'].includes('Mobi') ? 'Mobile' : 'Desktop',
        referer: req.headers['referer'] || 'Direct',
    });
    await visit.save();
}

module.exports = router;



