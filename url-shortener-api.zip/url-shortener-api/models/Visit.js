// models/Visit.js
const mongoose = require('mongoose');

const visitSchema = new mongoose.Schema({
  shortCode: { type: String, required: true },
  userAgent: { type: String, required: true },
  ipAddress: { type: String, required: true },
  deviceType: { type: String, required: true },
  referer: { type: String, default: 'Direct' },
  timestamp: { type: Date, default: Date.now },
});

module.exports = mongoose.model('Visit', visitSchema);



  
