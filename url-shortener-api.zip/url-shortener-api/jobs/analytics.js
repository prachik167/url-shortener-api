const Queue = require('bull');
const analyticsQueue = new Queue('analytics', 'redis://127.0.0.1:6379'); // Connect to Redis instance

// Process the job queue to aggregate analytics
analyticsQueue.process(async (job) => {
  const { shortCode } = job.data;
  console.log(`Processing analytics job for shortCode: ${shortCode}`);
  
  // Example: Log the processing
  console.log(`Analytics data processed for: ${shortCode}`);
});

module.exports = analyticsQueue;

